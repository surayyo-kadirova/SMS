﻿using MediatR;
using SMS.Business.CQRS.Queries;
using SMS.DatabaseContext.Abstract;
using SMS.Entities;

namespace SMS.Business.CQRS.QueryHandlers
{
	public class GetAllStudentsQueryHandler:IRequestHandler<GetAllStudentsQuery, List<Student>>
	{
        private readonly ISMSRepository _repository;

        public GetAllStudentsQueryHandler(ISMSRepository repository)
        {
            _repository = repository;
        }

        public async Task<List<Student>>Handle(GetAllStudentsQuery request, CancellationToken cancellationToken)
        {
            return await _repository.GetAllStudents();
        }

    }
}

