﻿using MediatR;
using SMS.Business.CQRS.Queries;
using SMS.DatabaseContext.Abstract;
using SMS.Entities;

namespace SMS.Business.CQRS.QueryHandlers
{
	public class GetStudentByIdQueryHandler: IRequestHandler<GetStudentByIdQuery, Student>
	{
        private readonly ISMSRepository _repository;

        public GetStudentByIdQueryHandler(ISMSRepository repository)
        {
            _repository = repository;
        }

        public async Task<Student>Handle(GetStudentByIdQuery request, CancellationToken cancellationToken)
        {
            return await _repository.GetStudentById(request.Id);
        }
    }
}

