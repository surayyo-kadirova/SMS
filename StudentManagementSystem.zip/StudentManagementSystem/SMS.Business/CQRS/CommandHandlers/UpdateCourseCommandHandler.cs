﻿using System;
using MediatR;
using SMS.Business.CQRS.Commands;
using SMS.DatabaseContext.Abstract;
using SMS.Entities;

namespace SMS.Business.CQRS.CommandHandlers
{
	public class UpdateCourseCommandHandler: IRequestHandler<UpdateCourseCommand, Course>
	{
		private readonly ICourseRepository _courseRepository;

		public UpdateCourseCommandHandler(ICourseRepository courseRepository)
		{
			_courseRepository = courseRepository;
		}

		public async Task<Course>Handle(UpdateCourseCommand request,CancellationToken cancellationToken)
		{
			var course = new Course
			{
				CourseName = request.CourseName
			};

			return await _courseRepository.UpdateCourse(course);
		}
	}
}

