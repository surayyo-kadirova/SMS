﻿using System;
using MediatR;
using SMS.Business.CQRS.Commands;
using SMS.DatabaseContext.Abstract;
using SMS.Entities;

namespace SMS.Business.CQRS.CommandHandlers
{
    public class CreateStudentCommandHandler : IRequestHandler<CreateStudentCommand, Student>
    {
        private readonly ISMSRepository _repository;

        public CreateStudentCommandHandler(ISMSRepository repository)
        {
            _repository = repository;
        }

        public async Task<Student> Handle(CreateStudentCommand request, CancellationToken cancellationToken)
        {
            var student = new Student
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
                DateOfBirth = request.DateOfBirth,
                Email = request.Email,
                PhoneNumber = request.PhoneNumber
            };

            return await _repository.CreateStudent(student);
        }
    }
}

