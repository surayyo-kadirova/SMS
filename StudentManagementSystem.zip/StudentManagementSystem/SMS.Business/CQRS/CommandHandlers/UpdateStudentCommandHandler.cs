﻿using MediatR;
using SMS.Business.CQRS.Commands;
using SMS.DatabaseContext.Abstract;
using SMS.Entities;

namespace SMS.Business.CQRS.CommandHandlers
{
	public class UpdateStudentCommandHandler: IRequestHandler<UpdateStudentCommand, Student>
	{
        private readonly ISMSRepository _repository;

        public UpdateStudentCommandHandler(ISMSRepository repository)
        {
            _repository = repository;
        }

        public async Task<Student>Handle(UpdateStudentCommand request, CancellationToken cancellationToken)
        {
            var student = new Student
            {
                Id = request.Id,
                FirstName = request.FirstName,
                LastName = request.LastName,
                DateOfBirth = request.DateOfBirth,
                Email = request.Email,
                PhoneNumber = request.PhoneNumber
            };

            return await _repository.UpdateStudent(student);

            }
        }
    
}

