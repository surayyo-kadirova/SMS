﻿using System;
using MediatR;
using SMS.Entities;

namespace SMS.Business.CQRS.Queries
{
    public class GetAllStudentsQuery : IRequest<List<Student>>
    {
    }
}

