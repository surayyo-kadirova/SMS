﻿using System;
using MediatR;
using SMS.Entities;

namespace SMS.Business.CQRS.Queries
{
	public class GetAllCoursesQuery:IRequest<List<Course>>
	{
		
	}
}

