﻿
using MediatR;
using SMS.Entities;

namespace SMS.Business.CQRS.Queries
{
    public class GetStudentByIdQuery : IRequest<Student>
    {
        public int Id { get; set; }
    }
}

