﻿using System;
using MediatR;
using SMS.Entities;

namespace SMS.Business.CQRS.Commands
{
	public class CreateCourseCommand: IRequest<Course>
	{
		public string CourseName { get; set; }
		
	}
}

