﻿using System;
using MediatR;
using SMS.Entities;

namespace SMS.Business.CQRS.Commands
{
	public class UpdateCourseCommand: IRequest<Course>
	{
		public int Id { get; set; }
		public string CourseName { get; set; }
		
	}
}

