﻿using System;
using MediatR;

namespace SMS.Business.CQRS.Commands
{
	
        public class DeleteStudentCommand : IRequest
        {
            public int Id { get; set; }
        }
    
}

