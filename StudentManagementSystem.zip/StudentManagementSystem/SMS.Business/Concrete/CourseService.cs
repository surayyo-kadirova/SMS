﻿using System;
using SMS.Business.Abstract;
using SMS.DatabaseContext.Abstract;
using SMS.DatabaseContext.Concrete;
using SMS.Entities;

namespace SMS.Business.Concrete
{
    public class CourseService : ICourseService
    {
        private readonly ICourseRepository _courseRepository;

        public CourseService(ICourseRepository courseRepository)
        {
            _courseRepository = courseRepository;
        }

        public async Task<List<Course>> GetAllCourses()
        {
            return await _courseRepository.GetAllCourses();
        }

        public async Task<Course> GetCourseById(int Id)
        {
            if (Id >= 0)
            {
                return await _courseRepository.GetCourseById(Id);

            }

            else
            {
                throw new Exception("Id can not be less than 1");
            }
        }

        public async Task<Course> CreateCourse(Course course)
        {
            return await _courseRepository.CreateCourse(course);

        }

        public async Task<Course> UpdateCourse(Course course)
        {
            return await _courseRepository.UpdateCourse(course);
        }

        public async Task DeleteCourse(int Id)
        {
            if (Id >= 0)
            {
                await _courseRepository.DeleteCourse(Id);

            }
            else
            {
                throw new Exception("Id can not be less than 1");
            }

        }



    }
}

