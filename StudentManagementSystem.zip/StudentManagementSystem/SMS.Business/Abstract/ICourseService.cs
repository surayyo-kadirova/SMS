﻿using System;
using SMS.DatabaseContext.Concrete;
using SMS.Entities;

namespace SMS.Business.Abstract
{
    public interface ICourseService 
	{
        Task<List<Course>> GetAllCourses();
        Task<Course> GetCourseById(int id);
        Task<Course> CreateCourse(Course course);
        Task<Course> UpdateCourse(Course course);
        Task DeleteCourse(int id);
    }
}

