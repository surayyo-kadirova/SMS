﻿using System;
using SMS.Entities;

namespace SMS.DatabaseContext.Abstract
{
	public interface ISMSRepository
	{
      
            Task<List<Student>> GetAllStudents();

            Task<Student> GetStudentById(int Id);

            Task<Student> CreateStudent(Student student);

            Task<Student> UpdateStudent(Student student);

            Task DeleteStudent (int Id);   //void olan method olduğu için herhangi bir tip belirtmiyoruz
        
    }
}

