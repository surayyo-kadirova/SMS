﻿using System;
using SMS.Entities;

namespace SMS.DatabaseContext.Abstract
{
	public interface ICourseRepository
	{
        Task<List<Course>> GetAllCourses();

        Task<Course> GetCourseById(int Id);

        Task<Course> CreateCourse(Course course);

        Task<Course> UpdateCourse(Course course);

        Task DeleteCourse(int Id);
    }
}

