﻿using System;
using Microsoft.EntityFrameworkCore;
using SMS.DatabaseContext.Abstract;
using SMS.Entities;

namespace SMS.DatabaseContext.Concrete
{
	public class CourseRepository: ICourseRepository
	{
        public SMSDb context = new(); //context yaratmış olduk ve alttakı butun fonksuyonlar görebilir.


        public async Task<List<Course>> GetAllCourses()
        {
            return await context.Courses.ToListAsync();
        }

        public async Task<Course> GetCourseById(int Id)
        {
            return await context.Courses.FirstOrDefaultAsync(h => h.Id == Id);
        }

        public async Task<Course> CreateCourse(Course course)
        {
            context.Courses.Add(course);
            await context.SaveChangesAsync();
            return course;

        }

        public async Task<Course> UpdateCourse(Course course)
        {
            var existingCourse = await context.Courses.FirstOrDefaultAsync(s => s.Id == course.Id);
            if (existingCourse != null)
            {

                existingCourse.CourseName = course.CourseName;

                //hotelDbContext.Entry(existingHotel).CurrentValues.SetValues(hotel);

                await context.SaveChangesAsync();
                return existingCourse;
            }

            else
            {
                return null;
            }
        }

        public async Task DeleteCourse(int Id)
        {

            var existingCourse = await GetCourseById(Id);
            context.Courses.Remove(existingCourse);
            await context.SaveChangesAsync();

        }

      
    }

}


