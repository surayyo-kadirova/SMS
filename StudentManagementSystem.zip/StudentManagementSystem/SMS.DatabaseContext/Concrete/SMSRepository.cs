﻿using System;
using Microsoft.EntityFrameworkCore;
using SMS.DatabaseContext.Abstract;
using SMS.Entities;

namespace SMS.DatabaseContext.Concrete
{

    public class SMSRepository : ISMSRepository
    {
        public SMSDb context = new(); //context yaratmış olduk ve alttakı butun fonksuyonlar görebilir.


        public async Task<List<Student>> GetAllStudents()
        {
            return await context.Students.ToListAsync();
        }

        public async Task<Student> GetStudentById(int Id)
        {
            return await context.Students.FirstOrDefaultAsync(h => h.Id == Id);
        }

        public async Task<Student> CreateStudent(Student student)
        {
            context.Students.Add(student);
            await context.SaveChangesAsync();
            return student;

        }

        public async Task<Student> UpdateStudent(Student student)
        {
            var existingStudent = await context.Students.FirstOrDefaultAsync(s => s.Id == student.Id);
            if (existingStudent != null)
            {

                existingStudent.FirstName = student.FirstName;
                existingStudent.LastName = student.LastName;
                existingStudent.DateOfBirth = student.DateOfBirth;
                existingStudent.Email = student.Email;
                existingStudent.PhoneNumber = student.PhoneNumber;

                //hotelDbContext.Entry(existingHotel).CurrentValues.SetValues(hotel);

                await context.SaveChangesAsync();
                return existingStudent;
            }

            else
            {
                return null;
            }
        }

        public async Task DeleteStudent(int Id)
        {

            var existingStudent = await GetStudentById(Id);
            context.Students.Remove(existingStudent);
            await context.SaveChangesAsync();

        }

        public Task<List<Student>> GetAllStudent()
        {
            throw new NotImplementedException();
        }
    }
}
    


      


      