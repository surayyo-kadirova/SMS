﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SMS.DatabaseContext.Migrations
{
    /// <inheritdoc />
    public partial class ResetAutoIncrement : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("ALTER TABLE Students AUTO_INCREMENT = 1;");

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
