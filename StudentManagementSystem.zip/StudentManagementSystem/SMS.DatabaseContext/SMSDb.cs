﻿using Microsoft.EntityFrameworkCore;
using SMS.Entities;

namespace SMS.DatabaseContext
{
	public class SMSDb: DbContext
	{
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
            optionsBuilder.UseMySQL("Server=localhost, 3306;Database=StudentManagementSystem;User ID=root;Password=Mesut@8541");
        }

        public DbSet<Student> Students{ get; set; }
        public DbSet<Course> Courses { get; set; }

       /* protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Student>()
                .HasOne(s => s.Course)
                .WithMany(c => c.Students)
                .HasForeignKey(s => s.CourseId)
                .OnDelete(DeleteBehavior.Cascade);
        }*/


    }

}

