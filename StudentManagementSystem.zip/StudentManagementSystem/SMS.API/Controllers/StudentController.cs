﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Hosting;
using SMS.Business.Abstract;
using SMS.Entities;


namespace SMS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController] //otomatik validation yapar
    public class StudentController : Controller
    {
        private ISMSService _smsService;

        public StudentController(ISMSService smsService)
        {
            _smsService = smsService;
        }
    

            [HttpGet]
            public async Task<IActionResult> GetAllStudents() 
            {
                var students = await _smsService.GetAllStudents();
                return Ok(students);
            }

            [HttpGet("{Id}")]

            public async Task<IActionResult> GetStudentById(int Id) 
            {
                var student = await _smsService.GetStudentById(Id);
                if (student != null)
                {
                    return Ok(student);
                }
                return NotFound();
            }



            [HttpPost]
            public async Task<ActionResult<Student>> Create([FromBody] Student student)
            {
                var createdStudent = await _smsService.CreateStudent(student);
                return CreatedAtAction("Get", new { id = createdStudent.Id }, createdStudent);
            }

            [HttpPost("{update}")]

            public async Task<IActionResult> UpdateStudent([FromBody] Student student)
            {
                if (student == null || student.Id == 0)
                {
                    return BadRequest("Invalid student data.");
                }

                var updatedStudent = await _smsService.UpdateStudent(student);
                if (updatedStudent == null)
                {
                    return NotFound("Student not found.");
                }

                return Ok(updatedStudent);
            }



            [HttpDelete("{Id}")]

            public async Task Delete(int Id)
            {
                if (await _smsService.GetStudentById(Id) != null)
                {
                    await _smsService.DeleteStudent(Id);
                }


            }

        }
    }*/

