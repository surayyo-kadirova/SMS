﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using SMS.Business.CQRS.Commands;
using SMS.Business.CQRS.Queries;
using SMS.Entities;
using System.Threading.Tasks;

namespace SMS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CQRStudentController : ControllerBase
    {
        private readonly IMediator _mediator;

        public CQRStudentController(IMediator mediator)
        {
            _mediator = mediator;
        }
        /// <summary>
        /// Get All Students
        /// </summary>
        /// <returns></returns
        [HttpGet]
        public async Task<IActionResult> GetAllStudents()
        {
            var students = await _mediator.Send(new GetAllStudentsQuery());
            return Ok(students);
        }

        // Get a student by ID
        [HttpGet("{id}")]
        public async Task<IActionResult> GetStudentById(int id)
        {
            var student = await _mediator.Send(new GetStudentByIdQuery { Id = id });
            if (student == null)
            {
                return NotFound();
            }
            return Ok(student);
        }

        // Create a new student
        [HttpPost]
        public async Task<IActionResult> CreateStudent([FromBody] CreateStudentCommand command)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var createdStudent = await _mediator.Send(command);
            return CreatedAtAction(nameof(GetStudentById), new { id = createdStudent.Id }, createdStudent);
        }

        // Update an existing student
        [HttpPost("{update}")]
        public async Task<IActionResult> UpdateStudent([FromBody] UpdateStudentCommand command)
        {

            var updatedStudent = await _mediator.Send(command);
            if (updatedStudent == null)
            {
                return NotFound("Student not found.");
            }
            return Ok(updatedStudent);
        }

        // Delete a student by ID

        [HttpDelete("{Id}")]
        public async Task Delete(int Id)
        {
            await _mediator.Send(new DeleteStudentCommand { Id = Id });
        }
    }
}

