﻿// In Program.cs for .NET 6 and later
using SMS.Business.Abstract;
using SMS.Business.Concrete;
using SMS.DatabaseContext.Abstract;
using SMS.DatabaseContext.Concrete;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddControllers();

// Dependency Injection için konteyner oluşturma
builder.Services.AddSingleton<ISMSService, SMSService>();
builder.Services.AddSingleton<ISMSRepository, SMSRepository>();

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseCors(options =>
{
    options.AllowAnyHeader();
    options.AllowAnyOrigin();
    options.AllowAnyMethod();
});
app.UseAuthorization();
app.MapControllers();

app.Run();






